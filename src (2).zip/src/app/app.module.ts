import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
//import {  } from '@angular/material'


import { AppComponent } from './app.component';
//import { AppRoutingModule } from './/app-routing.module';
import { VideosComponent } from './videos/videos.component';
import { RouterModule, Routes } from '@angular/router';
import { HomepageComponent } from './homepage/homepage.component';
import { VideoListService } from './shared/videoList.service';
import { VideoFilterPipe } from './shared/videofilter.pipe';
import { BooksComponent } from './books/books.component';
import { ListenComponent } from './listen/listen.component';


@NgModule({
  declarations: [
    AppComponent,
    VideosComponent,
    HomepageComponent,
    VideoFilterPipe,
    BooksComponent,
    ListenComponent    
  ],
  imports: [
    BrowserModule,
     RouterModule.forRoot(
      [{path:'home', component:HomepageComponent},
      {path:'video', component:VideosComponent},
      {path:'listen', component:ListenComponent},
      {path:'books', component:BooksComponent},
      {path: '',     redirectTo: 'home', pathMatch: 'full' }]
    )
  ],
  providers: [VideoListService, VideoFilterPipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
