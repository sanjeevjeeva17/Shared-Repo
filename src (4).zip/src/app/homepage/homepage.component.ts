import { Component, OnInit } from '@angular/core';
import { HomeVideoListService } from '../shared/homeVideoList.service';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  visibleVideos: any[] =[];
  visibleAudios: any[] =[];
  visibleBooks: any[] =[];

    constructor(private HomevideoListService: HomeVideoListService){
            this.visibleVideos = this.HomevideoListService.getVideos();
            this.visibleAudios = this.HomevideoListService.getAudios();
            this.visibleBooks = this.HomevideoListService.getBooks();
    }

  ngOnInit() {
  }

}
