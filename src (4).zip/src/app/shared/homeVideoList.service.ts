import{ Injectable } from '@angular/core';

@Injectable()


export class HomeVideoListService{
    HomeVideos = [];
    HomeAudios = [];
    HomeBooks = [];
    getVideos(){
        return this.HomeVideos = VIDEO.slice(0);
    };
    getAudios(){
        return this.HomeAudios = AUDIO.slice(0);
    };
    getBooks(){
        return this.HomeBooks = BOOK.slice(0);
    };

}

const VIDEO = [

	{
		"imgSrc":"https://i.ytimg.com/vi/0tyRis6Md6A/hqdefault.jpg?sqp=-oaymwEZCPYBEIoBSFXyq4qpAwsIARUAAIhCGAFwAQ==&amp;rs=AOn4CLDSRKppus6pOdQM07le1LLfkCIwUQ",
        "title":"Revelation: The Bride, The Beast, &amp; Babylon - Nepali Voice Over (दुलही,पशु र बेबीलोन) fin",
        "subtitle":"By Pastor Raj on Januray 4 2018",
        "Description":"John saw it rise up out of the sea, having seven heads and ten horns, and upon his horns ten crowns, and upon his heads the name of blasphemy. (Revelation 13:1) It was like a leopard, with feet like the feet of a bear, and had a mouth like a lion."
	},
	{
		"imgSrc":"https://i.ytimg.com/vi/0tyRis6Md6A/hqdefault.jpg?sqp=-oaymwEZCPYBEIoBSFXyq4qpAwsIARUAAIhCGAFwAQ==&amp;rs=AOn4CLDSRKppus6pOdQM07le1LLfkCIwUQ",
        "title":"Revelation: The Bride, The Beast, &amp; Babylon - Nepali Voice Over (दुलही,पशु र बेबीलोन) fin",
        "subtitle":"By Pastor Raj on Januray 4 2018",
        "Description":"John saw it rise up out of the sea, having seven heads and ten horns, and upon his horns ten crowns, and upon his heads the name of blasphemy. (Revelation 13:1) It was like a leopard, with feet like the feet of a bear, and had a mouth like a lion."
	},
	{
		"imgSrc":"https://i.ytimg.com/vi/0tyRis6Md6A/hqdefault.jpg?sqp=-oaymwEZCPYBEIoBSFXyq4qpAwsIARUAAIhCGAFwAQ==&amp;rs=AOn4CLDSRKppus6pOdQM07le1LLfkCIwUQ",
        "title":"Revelation: The Bride, The Beast, &amp; Babylon - Nepali Voice Over (दुलही,पशु र बेबीलोन) fin",
        "subtitle":"By Pastor Raj on Januray 4 2018",
        "Description":"John saw it rise up out of the sea, having seven heads and ten horns, and upon his horns ten crowns, and upon his heads the name of blasphemy. (Revelation 13:1) It was like a leopard, with feet like the feet of a bear, and had a mouth like a lion."
	},
	{
		"imgSrc":"https://i.ytimg.com/vi/0tyRis6Md6A/hqdefault.jpg?sqp=-oaymwEZCPYBEIoBSFXyq4qpAwsIARUAAIhCGAFwAQ==&amp;rs=AOn4CLDSRKppus6pOdQM07le1LLfkCIwUQ",
        "title":"Revelation: The Bride, The Beast, &amp; Babylon - Nepali Voice Over (दुलही,पशु र बेबीलोन) fin",
        "subtitle":"By Pastor Raj on Januray 4 2018",
        "Description":"John saw it rise up out of the sea, having seven heads and ten horns, and upon his horns ten crowns, and upon his heads the name of blasphemy. (Revelation 13:1) It was like a leopard, with feet like the feet of a bear, and had a mouth like a lion."
	},
	{
		"imgSrc":"https://i.ytimg.com/vi/0tyRis6Md6A/hqdefault.jpg?sqp=-oaymwEZCPYBEIoBSFXyq4qpAwsIARUAAIhCGAFwAQ==&amp;rs=AOn4CLDSRKppus6pOdQM07le1LLfkCIwUQ",
        "title":"Revelation: The Bride, The Beast, &amp; Babylon - Nepali Voice Over (दुलही,पशु र बेबीलोन) fin",
        "subtitle":"By Pastor Raj on Januray 4 2018",
        "Description":"John saw it rise up out of the sea, having seven heads and ten horns, and upon his horns ten crowns, and upon his heads the name of blasphemy. (Revelation 13:1) It was like a leopard, with feet like the feet of a bear, and had a mouth like a lion."
	},
	{
		"imgSrc":"https://i.ytimg.com/vi/0tyRis6Md6A/hqdefault.jpg?sqp=-oaymwEZCPYBEIoBSFXyq4qpAwsIARUAAIhCGAFwAQ==&amp;rs=AOn4CLDSRKppus6pOdQM07le1LLfkCIwUQ",
        "title":"Revelation: The Bride, The Beast, &amp; Babylon - Nepali Voice Over (दुलही,पशु र बेबीलोन) fin",
        "subtitle":"By Pastor Raj on Januray 4 2018",
        "Description":"John saw it rise up out of the sea, having seven heads and ten horns, and upon his horns ten crowns, and upon his heads the name of blasphemy. (Revelation 13:1) It was like a leopard, with feet like the feet of a bear, and had a mouth like a lion."
    },
    {
        "imgSrc":"https://i.ytimg.com/vi/0tyRis6Md6A/hqdefault.jpg?sqp=-oaymwEZCPYBEIoBSFXyq4qpAwsIARUAAIhCGAFwAQ==&amp;rs=AOn4CLDSRKppus6pOdQM07le1LLfkCIwUQ",
        "title":"Revelation: The Bride, The Beast, &amp; Babylon - Nepali Voice Over (दुलही,पशु र बेबीलोन) fin",
        "subtitle":"By Pastor Raj on Januray 4 2018",
        "Description":"John saw it rise up out of the sea, having seven heads and ten horns, and upon his horns ten crowns, and upon his heads the name of blasphemy. (Revelation 13:1) It was like a leopard, with feet like the feet of a bear, and had a mouth like a lion."
	}


]

const AUDIO = [

	{
		"imgSrc":"assets/img/faces/face_1.png",
        "title":"Revelation: The Bride, The Beast, &amp; Babylon - Nepali Voice Over (दुलही,पशु र बेबीलोन) fin",
        "subtitle":"By Pastor Raj on Januray 4 2018",
        "Description":"John saw it rise up out of the sea, having seven heads and ten horns, and upon his horns ten crowns, and upon his heads the name of blasphemy. (Revelation 13:1) It was like a leopard, with feet like the feet of a bear, and had a mouth like a lion."
	},
	{
		"imgSrc":"https://i.ytimg.com/vi/0tyRis6Md6A/hqdefault.jpg?sqp=-oaymwEZCPYBEIoBSFXyq4qpAwsIARUAAIhCGAFwAQ==&amp;rs=AOn4CLDSRKppus6pOdQM07le1LLfkCIwUQ",
        "title":"Revelation: The Bride, The Beast, &amp; Babylon - Nepali Voice Over (दुलही,पशु र बेबीलोन) fin",
        "subtitle":"By Pastor Raj on Januray 4 2018",
        "Description":"John saw it rise up out of the sea, having seven heads and ten horns, and upon his horns ten crowns, and upon his heads the name of blasphemy. (Revelation 13:1) It was like a leopard, with feet like the feet of a bear, and had a mouth like a lion."
	},
	{
		"imgSrc":"assets/img/faces/face_1.png",
        "title":"Revelation: The Bride, The Beast, &amp; Babylon - Nepali Voice Over (दुलही,पशु र बेबीलोन) fin",
        "subtitle":"By Pastor Raj on Januray 4 2018",
        "Description":"John saw it rise up out of the sea, having seven heads and ten horns, and upon his horns ten crowns, and upon his heads the name of blasphemy. (Revelation 13:1) It was like a leopard, with feet like the feet of a bear, and had a mouth like a lion."
	},
	{
		"imgSrc":"assets/img/faces/face_1.png",
        "title":"Revelation: The Bride, The Beast, &amp; Babylon - Nepali Voice Over (दुलही,पशु र बेबीलोन) fin",
        "subtitle":"By Pastor Raj on Januray 4 2018",
        "Description":"John saw it rise up out of the sea, having seven heads and ten horns, and upon his horns ten crowns, and upon his heads the name of blasphemy. (Revelation 13:1) It was like a leopard, with feet like the feet of a bear, and had a mouth like a lion."
	},
	{
		"imgSrc":"https://i.ytimg.com/vi/0tyRis6Md6A/hqdefault.jpg?sqp=-oaymwEZCPYBEIoBSFXyq4qpAwsIARUAAIhCGAFwAQ==&amp;rs=AOn4CLDSRKppus6pOdQM07le1LLfkCIwUQ",
        "title":"Revelation: The Bride, The Beast, &amp; Babylon - Nepali Voice Over (दुलही,पशु र बेबीलोन) fin",
        "subtitle":"By Pastor Raj on Januray 4 2018",
        "Description":"John saw it rise up out of the sea, having seven heads and ten horns, and upon his horns ten crowns, and upon his heads the name of blasphemy. (Revelation 13:1) It was like a leopard, with feet like the feet of a bear, and had a mouth like a lion."
	},
	{
		"imgSrc":"https://i.ytimg.com/vi/0tyRis6Md6A/hqdefault.jpg?sqp=-oaymwEZCPYBEIoBSFXyq4qpAwsIARUAAIhCGAFwAQ==&amp;rs=AOn4CLDSRKppus6pOdQM07le1LLfkCIwUQ",
        "title":"Revelation: The Bride, The Beast, &amp; Babylon - Nepali Voice Over (दुलही,पशु र बेबीलोन) fin",
        "subtitle":"By Pastor Raj on Januray 4 2018",
        "Description":"John saw it rise up out of the sea, having seven heads and ten horns, and upon his horns ten crowns, and upon his heads the name of blasphemy. (Revelation 13:1) It was like a leopard, with feet like the feet of a bear, and had a mouth like a lion."
    },
    {
		"imgSrc":"assets/img/faces/face_1.png",
        "title":"Revelation: The Bride, The Beast, &amp; Babylon - Nepali Voice Over (दुलही,पशु र बेबीलोन) fin",
        "subtitle":"By Pastor Raj on Januray 4 2018",
        "Description":"John saw it rise up out of the sea, having seven heads and ten horns, and upon his horns ten crowns, and upon his heads the name of blasphemy. (Revelation 13:1) It was like a leopard, with feet like the feet of a bear, and had a mouth like a lion."
	},


]

const BOOK = [

	{
		"imgSrc":"https://i.ytimg.com/vi/0tyRis6Md6A/hqdefault.jpg?sqp=-oaymwEZCPYBEIoBSFXyq4qpAwsIARUAAIhCGAFwAQ==&amp;rs=AOn4CLDSRKppus6pOdQM07le1LLfkCIwUQ",
        "title":"Revelation: The Bride, The Beast, &amp; Babylon - Nepali Voice Over (दुलही,पशु र बेबीलोन) fin",
        "subtitle":"By Pastor Raj on Januray 4 2018",
        "Description":"John saw it rise up out of the sea, having seven heads and ten horns, and upon his horns ten crowns, and upon his heads the name of blasphemy. (Revelation 13:1) It was like a leopard, with feet like the feet of a bear, and had a mouth like a lion."
	},
	{
		"imgSrc":"https://i.ytimg.com/vi/0tyRis6Md6A/hqdefault.jpg?sqp=-oaymwEZCPYBEIoBSFXyq4qpAwsIARUAAIhCGAFwAQ==&amp;rs=AOn4CLDSRKppus6pOdQM07le1LLfkCIwUQ",
        "title":"Revelation: The Bride, The Beast, &amp; Babylon - Nepali Voice Over (दुलही,पशु र बेबीलोन) fin",
        "subtitle":"By Pastor Raj on Januray 4 2018",
        "Description":"John saw it rise up out of the sea, having seven heads and ten horns, and upon his horns ten crowns, and upon his heads the name of blasphemy. (Revelation 13:1) It was like a leopard, with feet like the feet of a bear, and had a mouth like a lion."
	},
	{
		"imgSrc":"https://i.ytimg.com/vi/0tyRis6Md6A/hqdefault.jpg?sqp=-oaymwEZCPYBEIoBSFXyq4qpAwsIARUAAIhCGAFwAQ==&amp;rs=AOn4CLDSRKppus6pOdQM07le1LLfkCIwUQ",
        "title":"Revelation: The Bride, The Beast, &amp; Babylon - Nepali Voice Over (दुलही,पशु र बेबीलोन) fin",
        "subtitle":"By Pastor Raj on Januray 4 2018",
        "Description":"John saw it rise up out of the sea, having seven heads and ten horns, and upon his horns ten crowns, and upon his heads the name of blasphemy. (Revelation 13:1) It was like a leopard, with feet like the feet of a bear, and had a mouth like a lion."
	},
	{
		"imgSrc":"https://i.ytimg.com/vi/0tyRis6Md6A/hqdefault.jpg?sqp=-oaymwEZCPYBEIoBSFXyq4qpAwsIARUAAIhCGAFwAQ==&amp;rs=AOn4CLDSRKppus6pOdQM07le1LLfkCIwUQ",
        "title":"Revelation: The Bride, The Beast, &amp; Babylon - Nepali Voice Over (दुलही,पशु र बेबीलोन) fin",
        "subtitle":"By Pastor Raj on Januray 4 2018",
        "Description":"John saw it rise up out of the sea, having seven heads and ten horns, and upon his horns ten crowns, and upon his heads the name of blasphemy. (Revelation 13:1) It was like a leopard, with feet like the feet of a bear, and had a mouth like a lion."
	},
	{
		"imgSrc":"https://i.ytimg.com/vi/0tyRis6Md6A/hqdefault.jpg?sqp=-oaymwEZCPYBEIoBSFXyq4qpAwsIARUAAIhCGAFwAQ==&amp;rs=AOn4CLDSRKppus6pOdQM07le1LLfkCIwUQ",
        "title":"Revelation: The Bride, The Beast, &amp; Babylon - Nepali Voice Over (दुलही,पशु र बेबीलोन) fin",
        "subtitle":"By Pastor Raj on Januray 4 2018",
        "Description":"John saw it rise up out of the sea, having seven heads and ten horns, and upon his horns ten crowns, and upon his heads the name of blasphemy. (Revelation 13:1) It was like a leopard, with feet like the feet of a bear, and had a mouth like a lion."
	},
	{
		"imgSrc":"https://i.ytimg.com/vi/0tyRis6Md6A/hqdefault.jpg?sqp=-oaymwEZCPYBEIoBSFXyq4qpAwsIARUAAIhCGAFwAQ==&amp;rs=AOn4CLDSRKppus6pOdQM07le1LLfkCIwUQ",
        "title":"Revelation: The Bride, The Beast, &amp; Babylon - Nepali Voice Over (दुलही,पशु र बेबीलोन) fin",
        "subtitle":"By Pastor Raj on Januray 4 2018",
        "Description":"John saw it rise up out of the sea, having seven heads and ten horns, and upon his horns ten crowns, and upon his heads the name of blasphemy. (Revelation 13:1) It was like a leopard, with feet like the feet of a bear, and had a mouth like a lion."
    },
    {
		"imgSrc":"assets/img/faces/face_1.png",
        "title":"Revelation: The Bride, The Beast, &amp; Babylon - Nepali Voice Over (दुलही,पशु र बेबीलोन) fin",
        "subtitle":"By Pastor Raj on Januray 4 2018",
        "Description":"John saw it rise up out of the sea, having seven heads and ten horns, and upon his horns ten crowns, and upon his heads the name of blasphemy. (Revelation 13:1) It was like a leopard, with feet like the feet of a bear, and had a mouth like a lion."
	}


]

  