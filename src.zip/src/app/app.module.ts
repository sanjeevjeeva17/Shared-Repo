import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
//import { AppRoutingModule } from './/app-routing.module';
import { VideosComponent } from './videos/videos.component';
import { RouterModule, Routes } from '@angular/router';
import { HomepageComponent } from './homepage/homepage.component';


@NgModule({
  declarations: [
    AppComponent,
    VideosComponent,
    HomepageComponent    
  ],
  imports: [
    BrowserModule,
     RouterModule.forRoot(
      [{path:'home', component:HomepageComponent},
      {path:'video', component:VideosComponent},
      {path: '',     redirectTo: 'home', pathMatch: 'full' }]
    )
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
