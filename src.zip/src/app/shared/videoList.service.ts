import{ Injectable } from '@angular/core';

@Injectable()


export class VideoListService{
    VisibleVideos = [];
    getVideos(){
        return this.VisibleVideos = VIDEO.slice(0);
    }

    getVideo(id:number){
        return VIDEO.slice(0).find(video => video.id == id)
    }

}

const VIDEO = [

	{
		"id": 1,
		"category": "BIBLE_DOC",
		"title": "Nepali Christian The Bride, Beast, & Babylon – (दुलही,पशु र बेबीलोन) z",
		"url": "https://img.youtube.com/vi/0tyRis6Md6A/hqdefault.jpg"
	},
	{
		"id": 2,
		"category": "BIBLE_DOC",
		"title": "The Creation – The Earth is a Witness (सृष्टि – पृथ्वी साक्षी छ ) A",
		"url": "https://img.youtube.com/vi/rWuRl2AS2BA/hqdefault.jpg"
	},
	{
		"id": 3,
		"category": "BIBLE_DOC",
		"title": "Cosmic Conflict (ब्रहमाण्डीय द्वन्द्व) z",
		"url": "https://img.youtube.com/vi/hr2_03C-7nI/hqdefault.jpg"
	},
	{
		"id": 4,
		"category": "JOSEPH",
		"title": "Part 1 – Is God Responsible? (भाग १ – के पर्मेश्वर जिम्मेवर हुनुहुन्छ? ) z",
		"url": "https://img.youtube.com/vi/gEztECXSgNI/hqdefault.jpg"
	},
	{
		"id": 5,
		"category": "JOSEPH",
		"title": "Part 2 – Why Do Innocent People Suffer? (भाग २ – निर्दोष मानिसहरुलाई किन दु:ख र पीडा अाइपर्छ ? ) z",
		"url": "https://img.youtube.com/vi/kx-aDrg3hA0/hqdefault.jpg"
	},
	{
		"id": 6,
		"category": "JOSEPH",
		"title": "Part 3 – Will Suffering End? (भाग ३ – के कहिल्यै यसको अन्त हुन्छ?) z",
		"url": "https://img.youtube.com/vi/ovvDlCpLX4A/hqdefault.jpg"
	},
	{
		"id": 7,
		"category": "NUTITION",
		"title": "How to Make Charcoal (कोइलाको धूलो कसरी बनाउने ) z",
		"url": "https://img.youtube.com/vi/ovvDlCpLX4A/hqdefault.jpg"
	},
	{
		"id": 8,
		"category": "SABBATHSCHOOL",
		"title": "Gift of Tongue  Part-1(अन्य भाषाहरु बोल्ने बरदान) z",
		"url": "https://img.youtube.com/vi/ogBJ63XvCtw/hqdefault.jpg"
	},
	{
		"id": 9,
		"category": "SEVENTH",
		"title": "Nepali Christian – Sabbath part -1 (साँतौ दिन शबाथ भाग 1) LLT Prod",
		"url": "https://img.youtube.com/vi/2SsyMYonAU4/hqdefault.jpg"
	}


]

  